<?php

namespace App\Http\Controllers;

use App\Models\CategoryGames;
use App\Models\Games;
use Illuminate\Http\Request;

class CategoryGamesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categorygames = CategoryGames::orderBy('id', 'asc')->get();
        return view('CategoryGames.index', compact('categorygames'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('CategoryGames.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'categoryName' => 'required'
        ]);
        CategoryGames::create($request->all());
        return redirect('/categorygamelist');
    }

    public function listMeny()
    {


        $categoryGames = CategoryGames::orderBy('id', 'asc')->get();
        $games = Games::all();
        return view('CategoryGames.games', compact('categoryGames', 'games'));
    }

    public function gameByCategory(CategoryGames $categoryGames)
    {
        //$categoryGames -one category
        $categorys = CategoryGames::orderBy('id', 'asc')->get();
        $games = Games::where('category_id', $categoryGames->id)->get(); //::orderBy('created_at', 'desc')

        return view('CategoryGames.categorygame', compact('categorys', 'categoryGames', 'games'));
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CategoryGames  $categoryGames
     * @return \Illuminate\Http\Response
     */
    public function show(CategoryGames $categoryGames)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CategoryGames  $categoryGames
     * @return \Illuminate\Http\Response
     */
    public function edit(CategoryGames $categoryGames)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CategoryGames  $categoryGames
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CategoryGames $categoryGames)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CategoryGames  $categoryGames
     * @return \Illuminate\Http\Response
     */
    public function destroy(CategoryGames $categoryGames)
    {
        $categoryGames->delete();
        return redirect('/categorygamelist');
    }
}

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>HappyPC</title>		
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>HappyPC</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.7 -->
	<link rel="stylesheet" href='<?php echo e(asset("components/bootstrap/dist/css/bootstrap.min.css")); ?>'>
	<!-- Font Awesome -->
	<link rel="stylesheet" href='<?php echo e(asset("components/font-awesome/css/font-awesome.min.css")); ?>'>    
	<!-- Theme style -->
	<link rel="stylesheet" href='<?php echo e(asset("dist/css/AdminLTE.min.css")); ?>'>
	<link rel="stylesheet" href='<?php echo e(asset("dist/css/skins/_all-skins.min.css")); ?>'>  	
	<!-- Google Font -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  
	<!-- Custom style -->
	<link rel="stylesheet" href='<?php echo e(asset("dist/css/custom_style.css")); ?>'>
  <link rel="stylesheet" href='<?php echo e(asset("dist/css/clock.css")); ?>'>	
  <link rel="stylesheet" href='<?php echo e(asset("dist/css/tasklist1.css")); ?>'>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
  <!-- Logo -->
  <a href="<?php echo e(url('/')); ?>" class="logo"><!--  !!!!!!!!!!!!!!!!-->
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini"><b>P</b>N</span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><b>Happy</b>PC</span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a>
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <!-- User Account: style can be found in dropdown.less -->
        <li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <img src='<?php echo e(asset("images/profile.jpg")); ?>' class="user-image" alt="User Image">
            <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span><!-- изменить!       --> 
          </a>
          <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header">
              <img src='<?php echo e(asset("images/profile.jpg")); ?>' class="img-circle" alt="User Image">
              <p><?php echo e(Auth::user()->name); ?></p>
            </li>
            <li class="user-footer">
              <div class="pull-left">
                <a href="<?php echo e(url('/profile/'.Auth::user()->id )); ?>" class="btn btn-default btn-flat" id="admin_profile">Update</a><!-- изменить!       --> 
              </div>
              <div class="pull-right">
                <a href="<?php echo e(url('/logout')); ?>" class="btn btn-default btn-flat">Sign out</a>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>		
	
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src='<?php echo e(asset("images/profile.jpg")); ?>' class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
	  <p><?php echo e(Auth::user()->name); ?></p>    
      </div>
    </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">REPORTS</li>
      <li><a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
     
      
        
        
			<li><a href="<?php echo e(url('/categorylist')); ?>"><i class="fa fa-circle-o"></i> Categories</a></li>
			<li><a href="<?php echo e(url('/productlist')); ?>"><i class="fa fa-circle-o"></i> NewsList</a></li>
      <li><a href="<?php echo e(url('/gamelist')); ?>"><i class="fa fa-circle-o"></i> GameList</a></li>
      <li><a href="<?php echo e(url('/categorygamelist')); ?>"><i class="fa fa-circle-o"></i> GameCategoryList</a></li>
         
        
      </li>
    
		<?php if( Gate::allows('isAdmin')): ?>	  
	  <li><a href="<?php echo e(url('/users')); ?>"><i class="fa fa-users"></i> <span>Users</span></a></li>
    <li><a href="<?php echo e(url('/commentslist')); ?>"><i class="fa fa-comments"></i> <span>Comments</span></a></li>
    <?php endif; ?>
    </ul>
  </section>
  
  
  
  <!-- /.sidebar -->
</aside>	
	
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
      </h1>     
    </section>

    <!-- Main content -->
    <section class="content">           
      <div class="row">
       <!------------------CONTENT--------------------->
      </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
			  
             <?php echo $__env->yieldContent('content'); ?>
  
          </div>
        </div>
      </div>

      </section>
      <!-- end right col -->
    </div>

</div>
<!-- ./wrapper -->
	
	
<!-- jQuery 3 -->
<script src='<?php echo e(asset("components/jquery/dist/jquery.min.js")); ?>'></script>

<!-- jQuery UI 1.11.4 -->
<script src='<?php echo e(asset("components/jquery-ui/jquery-ui.min.js")); ?>'></script>
<!-- Bootstrap 3.3.7 -->
<script src='<?php echo e(asset("components/bootstrap/dist/js/bootstrap.min.js")); ?>'></script>
<!-- AdminLTE App -->
<script src='<?php echo e(asset("dist/js/adminlte.min.js")); ?>'></script>
<!-- Clock -->
<script src='<?php echo e(asset("dist/js/clock.js")); ?>'></script>

<!-- TaskList -->
<!-- <script src='<?php echo e(asset("dist/js/tasklist.js")); ?>'></script> -->
</body>
</html>	<?php /**PATH D:\LõpuTood_2023\JKTV21_Kolpakov\ProjectHappyPC-master\resources\views/layouts/app.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<div class="box-body" style="padding:50px;">

    <h1 style="padding:5px;"><?php echo e($games->title); ?></h1>
    <div class="row">

        <div class="col-md-4">
            <img class="img-thumbnail" style="width: 40vh;height:auto" src="../images/<?php echo e($games->image); ?>">
        </div>


        <div class="col-md-8">
            <strong>Описание:</strong>
            <p><?php echo e($games -> description); ?></p>

            <p>
                <?php $__currentLoopData = $categorygames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($games->category_id == $category->id): ?>
            <div value="<?php echo e($category->id); ?>">
                <strong>Category</strong> - <?php echo e($category -> categoryName); ?>

            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>
                <strong>Компания:</strong><?php echo e($games -> company); ?>

            </p>
            <p>
                <strong>Дата создания</strong><?php echo e($games -> datecreate); ?>

            </p>

            <p>Date Update - <?php echo e($games->updated_at->format('d-m-Y')); ?></p>

        </div>



        <div class="" style="margin-top:50px;padding-left:50px;">

            <a href="/games" class="btn btn-warning" style="font-size: 1.2em;">
                Back to game list
                <span class="glyphicon glyphicon-hand-down"></span>
            </a>

        </div>

    </div>




    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\popova\JKTV21\ProjectHappyPC-master\resources\views/games/detail.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<!-- content categories -->
<div class="box-header with-border">
    <h3 class="box-title"><strong> Games manage - Delete</strong></h3>
</div>
<div class="box-body">
    <div class="add">
        <a href="/productlist" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-backward"></i> Back</a>
    </div>
    <div class="container">
        <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Category EditForm -->
        <form action="" method="POST" enctype="">
			<?php echo csrf_field(); ?>			
			         <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Title:</strong>
                    <div><?php echo e($games -> description); ?></div>
                </div>
            </div>          
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Description:</strong>
                    <div  style="height:50px" 
                        placeholder="Description"><?php echo e($games -> description); ?></div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Category:</strong>
                
                    <div>
                        <?php $__currentLoopData = $categorygames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->id==$games->category_id): ?>
                                <?php echo e($category->categoryName); ?>

                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>

                        
                </div>
                <div class="form-group">
                        <strong>Image:</strong>
                </div>
                <img src="../images/<?php echo e($games -> image); ?>">                      
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Delete Game</button>
                </div>
            </div>
		</form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<!--  -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectHappyPC-master\resources\views/games/delete.blade.php ENDPATH**/ ?>
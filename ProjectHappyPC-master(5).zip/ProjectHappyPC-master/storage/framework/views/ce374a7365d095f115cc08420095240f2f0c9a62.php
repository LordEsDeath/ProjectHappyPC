<?php $__env->startSection('content'); ?>

    
    <div class="box-body">
        
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="form-group col-sm-3">

                <div class="img-thumbnail">
                    <img style="width: 250px;height:150px" src="../images/<?php echo e($task->image); ?>">
                </div>

                <p style="width: 250px;padding:5px;"><?php echo e($task->title); ?></p>

                <p>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($task->category_id == $category->id): ?> 
                            <div value="<?php echo e($category->id); ?>">
                                <strong>Category</strong> - <?php echo e($category -> name); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>

                <p>Date Update - <?php echo e($task->updated_at->format('d-m-Y')); ?></p>

                <a href="<?php echo e(url('show/'.$task->id)); ?>">Подробнее</a>
                
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jktv21_C\ProjectHappyPC-master\resources\views/startMainPage.blade.php ENDPATH**/ ?>
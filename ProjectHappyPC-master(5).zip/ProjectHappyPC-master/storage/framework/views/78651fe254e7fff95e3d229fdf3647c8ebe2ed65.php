<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Comment List manage</h3>
</div>

<?php if(count($comments ?? '') > 0): ?>
    <table class="table table-bordered">
        <thead>
            <th width=3%>N/#</th>
            <th width="10%">Comment</th>
            <th width=10%>User</th>
            <th width=10%>Date Create</th>
            <th width="50%">News</th>
            <th>Tools</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($index+1); ?> </td>
                    <td> <?php echo e($comment->body); ?> </td>
                    <td> <?php echo e($comment->user->name); ?> </td>
                    <td> <?php echo e($comment->created_at); ?> </td>
                    <td> 
                        (<?php echo e($comment->task->created_at->format('d.m.Y')); ?>) | <?php echo e($comment->task->title); ?> | 
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($comment->task_id == $task->id): ?> 
                             <a href="<?php echo e(url('show/'.$task->id)); ?>">Show news</a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                         
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-danger btn-lg" data-toggle="modal" data-target="#deleteComment<?php echo e($comment->id); ?>"><i class='fa fa-trash'></i> Delete </button>

                        <!-- Modal -->
                        <div class="modal fade" id="deleteComment<?php echo e($comment->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Comment</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Delete comment ?!?!
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                                    <form action="<?php echo e(url('deletecomment/'.$comment->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-primary">Delete</button>
                                    </form>
                                </div>

                            </div>
                        </div>
                        </div>
                    </td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>Data no found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LõpuTood_2023\JKTV21_Kolpakov\ProjectHappyPC-master\resources\views/tasks/comments.blade.php ENDPATH**/ ?>
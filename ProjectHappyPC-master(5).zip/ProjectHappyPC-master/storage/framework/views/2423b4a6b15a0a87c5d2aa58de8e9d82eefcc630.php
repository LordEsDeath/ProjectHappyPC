<?php $__env->startSection('content'); ?>


<div class="row">

    <div class="col-sm-3">
        <div class="column ms-5 nav">
            <h2>News Portal</h2>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(url('/news')); ?>" style="width:180px;">Все новости</a>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/categorynews/'.$cat->id)); ?>" style="width:180px;"><?php echo e($cat->name); ?> (<?php echo e(count($cat->task)); ?>)</a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="col-sm-9 mt-3">
        <h3>Категория: <?php echo e($category->name); ?></h3>
        <div class="col-md-5 offset-md-7">
            <form action="<?php echo e(url('newssort')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label> Sorting: </label>
                    <select class="form-control input-sm" name="sorting" onChange=submit();>
                        <?php $__currentLoopData = $sortinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sorting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"> <?php echo e($sorting); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </form>
        </div>
        <hr>

        <p class="text-end ps-5">Count of posts: <?php echo count($tasks); ?></p>
        <?php if(count($tasks)>0): ?>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="m-2 card">
                <h4 class="mt-3"><?php echo e($task->title); ?></h4>
                <p class="text-end">Date Update - <?php echo e($task->updated_at->format('d-m-Y')); ?></p>
                <img src="../images/<?php echo e($task->image); ?>">

            </div>

            <p>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($task->category_id == $category->id): ?>
            <div value="<?php echo e($category->id); ?>">
                <strong>Category</strong> - <?php echo e($category -> name); ?>

            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>Date Update - <?php echo e($task->updated_at->format('d-m-Y')); ?></p>
            <a class="btn btn-warning" href="<?php echo e(url('show/'.$task->id)); ?>">Подробнее</a>

            <!-- !!!!!!!!! -->
            <p class="commentscount text-end pe-5"><span class="spancomment"> Comments count: </span> <?php echo e(count($task->comments)); ?></p>
            <hr />
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="col-sm-9 mt-3">

            <p class="ps-5">No post</p>

        </div>
        <?php endif; ?>
    </div>


</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\popova\JKTV21\ProjectHappyPC-master\resources\views/categories/categorynews.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<!-- content categories list -->
<div class="box-header with-border">
    <h3 class="box-title"><strong>Categories manage - Add</strong></h3>
</div>
<div class="box-body">
    <div class="add">
        <a href="categorylist" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-backward"></i> Back</a>
    </div>
    <div class="container">
        <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- New Category Form -->
        <form action="<?php echo e(url('addcategory')); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>


            <!-- Category Name -->
            <div class="form-group">
                <label for="task-name" class="col-sm-3 control-label">Category</label>

                <div class="col-sm-6">
                    <input type="text" name="name" id="category-name" class="form-control" value="">
                </div>
            </div>

            <!-- Add Category Button -->
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-6">
                    <button type="submit" class="btn btn-default">
                        <i class="fa fa-btn fa-plus"></i> Add Category
                    </button>
                </div>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/categories/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <form action="<?php echo e(url('gamessort')); ?>" method="POST" >
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label> Sorting: </label>
            <select class="form-control input-sm" name="sorting" onChange=submit();>
                <?php $__currentLoopData = $sortinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sorting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"
                    
                    > <?php echo e($sorting); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

    </form>
    

    <div class="form-group col-md-2" style="width:200px;height:100vh">
        <h2>News Portal</h2>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(url('/news')); ?>">Все новости</a>
            </li>
            
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/categorynews/'.$category->id)); ?>"><?php echo e($category->name); ?> (<?php echo e(count($category->task)); ?>)</a>
                </li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="box-body">  
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group col-md-6" style="margin-left:50px;margin-top:50px;border:1px solid silver;border-radius:4px;padding:5px;">

            <div class="form-group col-md-4"  style="padding:10px;">
                <img class="img-thumbnail" style="width: 170px;height:auto" src="../images/<?php echo e($task->image); ?>">
            
            </div>
            <h4><?php echo e($task->title); ?></h4>
            <p>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($task->category_id == $category->id): ?> 
                        <div value="<?php echo e($category->id); ?>">
                            <strong>Category</strong> - <?php echo e($category -> name); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>Date Update - <?php echo e($task->updated_at->format('d-m-Y')); ?></p>
            <a class="btn btn-warning" href="<?php echo e(url('show/'.$task->id)); ?>">Подробнее</a>

            <!-- !!!!!!!!! -->
            <p class="commentscount"><span class="spancomment"> Comments count: </span> <?php echo e(count($task->comments)); ?></p>
            
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jktv21_C\ProjectHappyPC-master\resources\views/categories/news.blade.php ENDPATH**/ ?>
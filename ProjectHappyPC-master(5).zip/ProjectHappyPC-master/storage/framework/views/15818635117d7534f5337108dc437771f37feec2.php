<?php $__env->startSection('content'); ?>
<div class="box-header with-border">
    <h3 class="box-title"><strong> News List manage</strong></h3>
    <div class="add">
        <a href="addtask" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-plus"></i> New </a>
    </div>
    <!-- форма список категорий для фильтрации данных -->
    <div class="pull-right">
        <form class="form-inline" action="<?php echo e(url('productByCategory')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label> Category: </label>
                <select class="form-control input-sm" name="category_id" onChange=submit();>
                    <option value="0">All</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                        <?php if(isset($selectCategory) && $category->id == $selectCategory): ?> selected <?php endif; ?>
                        ><?php echo e($category -> name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="box-body">
    <?php if(count($tasks ?? '') > 0): ?>
    <table class="table table-bordered">
        <thead>
            <th width=3%>N/#</th>
            <th width="20%">Title</th>
            <th>Category</th>
            <th>Date Update</th>
            <th>Tools</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($task->id); ?> </td>
                    <td> <?php echo e($task->title); ?> </td>
                    <td> <?php echo e($task->category_id); ?> - <?php echo e($task->category->name); ?></td>
                    <td> <?php echo e($task->updated_at->format('d.m.Y')); ?></td>
                    <td>
                        <a href="<?php echo e(url('edittask/'.$task -> id)); ?>" class="btn btn-success btn-sm edit btn-flat"><i class="fa fa-edit"></i>Edit</a>
                        <a href="<?php echo e(url('deletetask/'.$task -> id)); ?>" class="btn btn-danger btn-sm edit btn-flat"><i class="fa fa-edit"></i>Delete</a>
                    </td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td colspan=4>
                        <?php echo e($task -> description); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>Data no found</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/tasks/index.blade.php ENDPATH**/ ?>
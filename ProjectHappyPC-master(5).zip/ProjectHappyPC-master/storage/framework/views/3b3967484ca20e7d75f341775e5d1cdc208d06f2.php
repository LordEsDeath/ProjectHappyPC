<?php $__env->startSection('content'); ?>
<div class="container">
	
	<div class="login-box">
		<div class="login-box-body">
			<?php if(session()->get('error')): ?>
				<div class="alert alert-danger">
					<?php echo e(session()->get('error')); ?>

				</div>
			<?php endif; ?>

		<p class="login-box-msg">Sign in to start your dashboard</p>
		<form action="<?php echo e(url('login')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="form-group has-feedback">
				<input type="email" class="form-control" name="email" placeholder="Email" required autofocus>
				<span class="glyphicon glyphicon-envelope form-control-feedback"></span>								
			</div>
			
			<div class="form-group has-feedback">
				<input type="password" class="form-control" name="password" placeholder="Password" required>
				<span class="glyphicon glyphicon-lock form-control-feedback"></span>			
			</div>
		  
			<div class="row">
				<div class="col-xs-4">
					<button type="submit" class="btn btn-primary btn-block btn-flat" name="login" style="backgroung-color:black;">
					<i class="fa fa-sign-in"></i> Sign In</button>
				</div>
			</div>
		</form>
		<br>      
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/start.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div>
<div class="col-xs-12 col-sm-12 col-md-12 text-center" style="padding-bottom:100px;">
    <p>Регистрация успешна, выполните вход на сайт <a href="<?php echo e(url('/login')); ?>">Login</a>.</p>
</div>
<div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/users/regSuccess.blade.php ENDPATH**/ ?>
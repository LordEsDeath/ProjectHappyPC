<?php $__env->startSection('content'); ?>
<!-- content categories list -->
<div class="box-title with-border">
    <h3 class="box-title"><strong> Categories manage</strong></h3>
</div>
<div class="box-body">
    <div class="add">
        <a href="addcategory" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-plus"></i> New</a>
    </div>
    <div class="container">
        <table id="example1" class="table table-bordered">
            <thead>
                <th>Category Name</th>
                <th>Tools</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <!-- форма отправит на маршрут удаления записи -->
                            <form action="<?php echo e(url('deletecategory/'.$category->id)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <!-- ссылка на маршрут редактирования -->
                                <a href="<?php echo e(url('editcategory/'.$category->id)); ?>" title="edit" type="button" class="btn btn-success btn-sm edit btn-flat"><i class="fa fa-edit"></i> Edit </a>
                                <button type="submit" class='btn btn-danger btn-sm delete btn-flat'>
                                    <i class="fa fa-trash"></i> Delete</button>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/categories/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html class="h-100">
<html>
<head>
  
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>HappyPC news</title>		
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>HappyPC news</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.7 -->
	<link rel="stylesheet" href='<?php echo e(asset("components/bootstrap/dist/css/bootstrap.min.css")); ?>'>
	<!-- Font Awesome -->
	<link rel="stylesheet" href='<?php echo e(asset("components/font-awesome/css/font-awesome.min.css")); ?>'>
    
	<!-- Theme style
	<link rel="stylesheet" href='<?php echo e(asset("dist/css/AdminLTE.min.css")); ?>'>	 -->
	<!-- Google Font -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	<!-- Custom style -->
	<link rel="stylesheet" href='<?php echo e(asset("dist/css/custom_style.css")); ?>'>	
</head>
<body class="d-flex flex-column h-100">
<header class="site-header sticky-top py-1">

        

            <!-- Left Side Of Navbar -->
            <nav class="container d-flex flex-column flex-md-row justify-content-between">
            <a class="py-2" href="<?php echo e(url('/')); ?>" >
                <img style="width: 250px; margin-left: 10px; border-radius: 10px;" src="<?php echo e(('/images/logo.png')); ?>">
            </a>
            <a class="py-2 d-none d-md-inline-block navbar-brand" href="<?php echo e(url('/')); ?>">Home</a>
            <a class="py-2 d-none d-md-inline-block navbar-brand" href="<?php echo e(url('/news')); ?>">News</a>
            <a class="py-2 d-none d-md-inline-block navbar-brand" href="<?php echo e(url('/games')); ?>">Games</a>

            <div class="navbar">
            <form action="/newssearch" class="navbar navbar-right" style="margin-right:10px;" method="POST">
        <?php echo csrf_field(); ?>
            
            <input style="border-radius: 10px; border: solid 1px black;" type="search" id="search" name="search">
            <input type="submit" value="Search">
        </form>
           </div>
            <!-- Right Side Of Navbar -->
           
            <!-- Authentication Links -->
            <?php if(Auth::guest()): ?>
           <a href="<?php echo e(url('/login')); ?>" class="py-2 d-none d-md-inline-block navbar-brand">Login</a>
           <a href="<?php echo e(url('/register')); ?>" class="py-2 d-none d-md-inline-block navbar-brand" style="margin-right:10px;">Register</a>
            <?php else: ?>
            <a href="<?php echo e(url('/dashboard')); ?>" class="navbar-brand">Admin panel</a>
                
                  <a href="<?php echo e(url('/logout')); ?>"  class="navbar-brand"><i class="fa fa-btn fa-sign-out"></i><?php echo e(strtoupper(Auth::user()->name)); ?> Logout</a>
            
        
     
            <?php endif; ?>
         
        </nav>

      

</header>
<main class="flex-shrink-0">
  <div class="container">

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
 </div>
</main>
    
<footer class="footer mt-auto py-3 bg-light">
     

    <div class="footer-content">
      <div class="footer-info">
        <h4>HappyPC</h4>
        <p>Adress: Kutse 13, Jõhvi, 41533 Ida-Viru maakond</p>
        <p>Phone: +37259043843</p>
      </div>
    </div>
</footer>
       <!-- jQuery 3 -->
  
       <script src='<?php echo e(asset("components/jquery/dist/jquery.min.js")); ?>'></script>

<!-- jQuery UI 1.11.4 -->
<script src='<?php echo e(asset("components/jquery-ui/jquery-ui.min.js")); ?>'></script>
<!-- Bootstrap 3.3.7 -->
<script src='<?php echo e(asset("components/bootstrap/dist/js/bootstrap.min.js")); ?>'></script>
<!-- AdminLTE App -->
<script src='<?php echo e(asset("dist/js/adminlte.min.js")); ?>'></script>
</body>
</html>	<?php /**PATH D:\LõpuTood_2023\JKTV21_Kolpakov\ProjectHappyPC-master\resources\views/layouts/appMain.blade.php ENDPATH**/ ?>
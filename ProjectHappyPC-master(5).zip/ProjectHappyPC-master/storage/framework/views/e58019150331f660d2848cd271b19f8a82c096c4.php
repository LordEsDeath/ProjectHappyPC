<?php $__env->startSection('content'); ?>
<div class="box-header with-border">
	<h3 class="box-title"><strong> Tasks manage - Add task</strong></h3>
	<div class="add">
	<a href="productlist" class="btn btn-primary btn-sm btn-flat"> <i class="fa fa-backward"></i> Back to list</a>
	</div>

</div>

<div class="box-body">
	<div class="container">
        <div class="col-lg-9 margin-tb">
			<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<strong>Error!</strong> 
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>
		<form action="" method="POST" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Title:</strong>
					<input type="text" name="title" class="form-control" placeholder="Title">
				</div>
			</div>	

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Description:</strong>
					<textarea class="form-control" style="height:50px" name="description"
						placeholder="Description"></textarea>
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Category:</strong>
				<select name="category_id" class="form-control" >															
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 						
						<option value="<?php echo e($category->id); ?>" ><?php echo e($category->name); ?></option>						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  
				</select>
				</div>
			</div>
			
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Image:</strong>
				  <input type="file" name="image"  class="form-control" value="">  
				</div>
			</div>	

			<div class="col-xs-12 col-sm-12 col-md-12 text-center">
				<button type="submit" class="btn btn-primary">Save task</button>
			</div>			
		</form>
		</div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jktv21_C\ProjectHappyPC-master\resources\views/tasks/create.blade.php ENDPATH**/ ?>
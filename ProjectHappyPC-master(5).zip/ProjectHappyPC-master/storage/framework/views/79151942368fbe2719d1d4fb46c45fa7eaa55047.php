<?php $__env->startSection('content'); ?>


<div class="mt-2 bg-light container-fluid">
    <div class="row">
        <div class="col-md-11 offset-md-3">
            <div class="g-3 row row-cols-md-3 row-cols-1">
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col">
                    <div class="m-2 card">


                        <img src="../images/<?php echo e($task->image); ?>">


                        <p style="padding:5px;"><?php echo e($task->title); ?></p>

                        <p>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($task->category_id == $category->id): ?>
                        <div value="<?php echo e($category->id); ?>">
                            <strong>Category</strong> - <?php echo e($category -> name); ?>

                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>

                        <p>Date Update - <?php echo e($task->updated_at->format('d-m-Y')); ?></p>

                        <a class="button" href="<?php echo e(url('show/'.$task->id)); ?>">Подробнее</a>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\popova\JKTV21\ProjectHappyPC-master\resources\views/startMainPage.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container">


    <div class="form-group col-md-2" style="width:200px;height:100vh">
        <h2>GamesCategory</h2>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(url('/games')); ?>">Все новости</a>
            </li>
            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/categoryGames/'.$categori->id)); ?>"><?php echo e($categori->categoryName); ?>  (<?php echo e(count($categori->gamess)); ?>)</a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php if(count($games)>0): ?>
     
    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      

        <div class="form-group col-md-6" style="margin-left:50px;margin-top:50px;border:1px solid silver;border-radius:4px;">

            <div class="form-group col-md-4"  style="padding:10px;">
                <img class="img-thumbnail" style="width: 170px;height:auto" src="../images/<?php echo e($game->image); ?>">
            
            </div>
            <h4><?php echo e($game->title); ?></h4>
            <p>
                <div>
                    <strong>Category</strong> - <?php echo e($categoryGames -> name); ?>

                </div>
            </p>
            <p>Date Update - <?php echo e($game->updated_at->format('d-m-Y')); ?></p>
            <a class="btn btn-warning" href="<?php echo e(url('show/'.$game->id)); ?>">Подробнее</a>

            <!-- !!!!!!!!! -->
            
        </div>
        
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <p>No data</p>
    <?php endif; ?>

</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/CategoryGames/categorygame.blade.php ENDPATH**/ ?>
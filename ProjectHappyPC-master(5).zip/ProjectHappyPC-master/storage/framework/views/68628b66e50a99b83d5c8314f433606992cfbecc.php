<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="box-header with-border">
        <h3 class="box-title"><storng> Dashboar Start page</strong><h3>
    </div>
    
    <hr>
    <div class="box-body" style="min-height:450px">
        Welcome dashboard page
        <div><br>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <div class="btn btn-warning btn-lg">
                    You have Admin Access
                </div>
            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isModerator')): ?>
                <div class="btn btn-success btn-lg">
                    You have Moderator Access
                </div>
            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
                <div class="btn btn-primary btn-lg">
                    You have User Access
                </div>
            <?php else: ?>
                <div class="btn btn-danger btn-lg">
                    You have not logged in
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectHappyPC-master\resources\views/dashboard.blade.php ENDPATH**/ ?>
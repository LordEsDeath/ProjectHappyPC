<?php $__env->startSection('content'); ?>
<div class="mt-2 bg-light container-fluid">
    <div style="border-radius: 30px ;border: 2px solid #F3F3F3; margin-top: 70px; box-shadow: 10px 5px 5px black; background-color: #F3F3F3 " class="box-body" style="padding:50px;">

        <h2 style="padding:25px; text-align: center;"><?php echo e($task->title); ?></h2>

        <div class="row">
            <div class="form-group col-md-4">
                <img class="img-thumbnail" src="../images/<?php echo e($task->image); ?>">
            </div>


            <div class="form-group col-md-6">
                <p><?php echo e($task -> description); ?></p>

                <p>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($task->category_id == $category->id): ?>
                <div value="<?php echo e($category->id); ?>">
                    <strong>Category</strong> - <?php echo e($category -> name); ?>

                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>

                <p>Date Update - <?php echo e($task->updated_at->format('d-m-Y')); ?></p>

            </div>

        </div>

        <div class="" style="margin-top:50px;padding-left:50px;">

            <a href="/news" class="btn btn-warning" style="font-size: 1.2em;">
                Back to list
                <span class="glyphicon glyphicon-hand-down"></span>
            </a>

        </div>
    </div>
    <hr>
    <?php if(Auth::check()): ?>

    <div class="container">
        <div class="col-sm-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4>Comments Add</h4>
                </div>
                <div class="panel-body">
                    <form action="<?php echo e(url('comments')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Comment text <i>(1000 symbols)</i></strong>
                                    <textarea class="form-control" style="height:50px" name="body" required></textarea>
                                </div>
                            </div>
                            <!-- Это id новости для комментов -->
                            <input type="hidden" name="taskid" value="<?php echo e($task->id); ?>" class="form-control" placeholder="newsId" readonly>
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Send comment</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <hr>
    <div class="comments">
        <h4 class="hComment">Comment List</h4>
        <hr>
        <?php $__empty_1 = true; $__currentLoopData = $task->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <p><i>Author: </i><?php echo e($comment->user->name); ?> <br>
            <i>Date created: </i><?php echo e(date('d-m-Y', strtotime($comment->created_at ))); ?>

        </p>
        <p>
            <span class="spanclass">Commnet: </span> <?php echo e($comment->body); ?>

        </p>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>This post has no commnets</p>
        <?php endif; ?>
    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\popova\JKTV21\ProjectHappyPC-master\resources\views/tasks/detail.blade.php ENDPATH**/ ?>
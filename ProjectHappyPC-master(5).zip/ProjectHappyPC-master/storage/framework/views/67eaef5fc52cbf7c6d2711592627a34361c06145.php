<?php $__env->startSection('content'); ?>
<div class="box-body">
    <div class="box-title">
        <h3 class="box-title"><strong>User manage</strong></h3>
    </div>
    <div class="add">
        <a href="adduser" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-plus"> New user</i></a>
    </div>

    <!-- форма списко ролей фильтрации пользователей -->
    <div class="pull-right">
        <form class="form-inline" action="<?php echo e(url('userByRole')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Role: </label>
                <select class="form-control input-sm" name="role" onChange=submit();>
                    <option value="0">All</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role); ?>"
                        <?php if(isset($selectRole) && $role==$selectRole): ?>
                            selected
                        <?php endif; ?>
                    ><?php echo e($role); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>

    
    <?php if(count($users ?? '') > 0): ?>
        <table class="table table-bordered">
            <thead>
                <th width=20%>Name#</th>
                <th width="20%">Emai</th>
                <th width="20%">Role</th>
                <th width="20%">Tools</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($user->name); ?> </td>
                        <td> <?php echo e($user->email); ?> </td>
                        <td> <?php echo e($user->role); ?> </td>
                        
                        <td>
                            <a href="<?php echo e(url('edituser/'.$user -> id)); ?>" class="btn btn-success btn-sm edit btn-flat"><i class="fa fa-edit"></i>Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Data no found</p>
    <?php endif; ?>

   <div class="container"></div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LõpuTood_2023\JKTV21_Kolpakov\ProjectHappyPC-master\resources\views/users/index.blade.php ENDPATH**/ ?>
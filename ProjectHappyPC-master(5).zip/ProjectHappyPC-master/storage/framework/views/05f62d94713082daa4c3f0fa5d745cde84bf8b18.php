

<?php $__env->startSection('content'); ?>
<div class="container">

    
    

    <div class="form-group col-md-2" style="width:200px;height:100vh">
        <h2>Games</h2>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(url('/games')); ?>">Все Игры</a>
            </li>
            
            <?php $__currentLoopData = $categoryGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/categoryGames/'.$category->id)); ?>"><?php echo e($category->categoryName); ?> (<?php echo e(count($category->gamess)); ?>)</a>
                </li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="box-body">  
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group col-md-6" style="margin-left:600px;margin-top:0px; right:500px; border:1px solid silver;border-radius:4px;padding:5px;">

            <div class="form-group col-md-4"  style="padding:10px;">
                <img class="img-thumbnail" style="width: 170px;height:auto" src="../images/<?php echo e($game->image); ?>">
            
            </div>
            <h4><?php echo e($game->title); ?></h4>
            <p>
                <?php $__currentLoopData = $categoryGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($game->category_id == $category->id): ?> 
                        <div value="<?php echo e($category->id); ?>">
                            <strong>Category</strong> - <?php echo e($category -> categoryName); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>Date Update - <?php echo e($game->updated_at->format('d-m-Y')); ?></p>
            <a class="btn btn-warning" href="<?php echo e(url('showgame/'.$game->id)); ?>">Подробнее</a>

   
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kostj\Desktop\ProjectHappyPC-master\resources\views/categoryGames/games.blade.php ENDPATH**/ ?>
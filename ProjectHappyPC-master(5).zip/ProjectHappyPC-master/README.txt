admin@news.ee 123456
user@news.ee 123456
moderator@news.ee 123456
@extends('layouts.appMain')

@section('content')
<div class="container">
    <div class="row">
        <h2>Games Portal</h2>
        <div class="col-sm-4">
            <div class="column ms-5 nav">

                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="{{ url('/games') }}" style="width:220px;">Все Игры</a>
                    </li>
                    @foreach ($categorys as $category)
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/categoryGames/'.$category->id) }}" style="width:220px;">{{$category->categoryName}} ({{ count($category->gamess) }})</a>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>





        <div class="col-sm-8">

            <p class="text-end ps-5">Count of games: <?php echo count($games); ?></p>
            <div class="row">
                <div class="col-md-12 offset-md-1">
                    <div class="g-2 row row-cols-md-3 row-cols-1">
                        @if(count($games)>0)
                        @foreach ($games as $game)

                        <div class="m-2 card">
                            <h4 class="mt-3">{{$game->title}}</h4>
                            <p class="text-start">Date Update - {{$game->updated_at->format('d-m-Y')}}</p>
                            <div class="col-md-3">
                                <img style="max-width: 100%;" src="../images/{{$game->image}}">
                            </div>

                            <div class="col-md-9 mt-3 pe-5">
                                <p>
                                    @foreach ($categorys as $category)
                                    @if($game->category_id == $category->id)
                                <div>
                                    <strong>Category</strong> - {{ $category -> categoryName }}
                                </div>
                                @endif
                                @endforeach
                                </p>


                                <a class="btn btn-warning" href="{{url('showgame/'.$game->id)}}" style="width:180px;">Подробнее</a>
                            </div>
                            <hr />
                        </div>

                        @endforeach



                        @else
                        <p>No data</p>
                        @endif
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>



@endsection
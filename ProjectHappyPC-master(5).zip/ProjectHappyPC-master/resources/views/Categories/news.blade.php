@extends('layouts.appMain')

@section('content')
<div class="mt-2 bg-light container-fluid">

    <div class="row">

        <div class="col-sm-3">
            <div class="flex-column ms-5 nav">
                <h2>News Portal</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="{{ url('/news') }}" style="width:180px;">Все новости</a>
                    </li>
                    @foreach ($categories as $category)
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/categorynews/'.$category->id) }}" style="width:180px;">{{$category->name}} ({{ count($category->task) }})</a>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
        <div class="col-sm-9 mt-3">
            <div class="col-md-5 offset-md-7">
                <form action="{{ url('newssort') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label> Sorting: </label>
                        <select class="form-control input-sm" name="sorting" onChange=submit();>
                            @foreach ($sortinglist as $key=>$sorting)
                            <option value="{{ $key }}"> {{ $sorting }} </option>
                            @endforeach
                        </select>
                    </div>

                </form>
            </div>
            <hr>
            <p class="text-end ps-5">Count of posts: <?php echo count($tasks); ?></p>
            @foreach ($tasks as $task)
            <div class="col">
                <div class="m-2 card">
                    <h4 class="mt-3">{{$task->title}}</h4>
                    <p class="text-end">Date Update - {{$task->updated_at->format('d-m-Y')}}</p>
                    <img src="../images/{{$task->image}}">

                </div>

                <p>
                    @foreach ($categories as $category)
                    @if($task->category_id == $category->id)
                <div value="{{ $category->id }}">
                    <strong>Category</strong> - {{ $category -> name }}
                </div>
                @endif
                @endforeach
                </p>

                <a class="btn btn-warning" href="{{url('show/'.$task->id)}}">Подробнее</a>

                <!-- !!!!!!!!! -->
                <p class="commentscount text-end pe-5"><span class="spancomment"> Comments count: </span> {{ count($task->comments) }}</p>
                <hr />
            </div>

            @endforeach
        </div>
    </div>

</div>
</div>
<hr>



@endsection
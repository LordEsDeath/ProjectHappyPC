@extends('layouts.appMain')

@section('content')

<div class="col-xs-12 col-sm-12 col-md-12 text-center" >
    <p>Регистрация успешна, выполните вход на сайт <a href="{{ url('/login') }}">Login</a>.</p>
</div>

@endsection

@extends('layouts.appMain')

@section('content')


<div class="mt-2 bg-light container-fluid">
    <div class="row">
        <div class="col-md-11 offset-md-3">
            <div class="g-3 row row-cols-md-3 row-cols-1">
                @foreach($tasks as $task)

                <div class="col">
                    <div class="m-2 card">


                        <img src="../images/{{$task->image}}">


                        <p style="padding:5px;">{{$task->title}}</p>

                        <p>
                            @foreach ($categories as $category)
                            @if($task->category_id == $category->id)
                        <div value="{{ $category->id }}">
                            <strong>Category</strong> - {{ $category -> name }}
                        </div>
                        @endif
                        @endforeach
                        </p>

                        <p>Date Update - {{$task->updated_at->format('d-m-Y')}}</p>

                        <a class="button" href="{{url('show/'.$task->id)}}">Подробнее</a>
                    </div>
                </div>

                @endforeach
            </div>
        </div>
    </div>
</div>


@endsection